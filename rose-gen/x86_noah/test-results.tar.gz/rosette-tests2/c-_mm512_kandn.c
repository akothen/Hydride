#include "../c-test-helper.h"
int main() {
uint8_t _0[2] = { 0x0,0x1 };__mmask16 a;memcpy(&a, _0, 2);
uint8_t _1[2] = { 0x0,0x1 };__mmask16 b;memcpy(&b, _1, 2);
uint8_t out[64] = {0};
__mmask16 ret = _mm512_kandn(a,b);
memcpy(out, &ret, 2);
hex_out(out, 2);
return 0;
}