#include "../c-test-helper.h"
int main() {
uint8_t _0[2] = { 0x0,0x1 };__mmask16 k;memcpy(&k, _0, 2);
uint8_t out[64] = {0};
__m256i ret = _mm256_broadcastmw_epi32(k);
memcpy(out, &ret, 32);
hex_out(out, 32);
return 0;
}