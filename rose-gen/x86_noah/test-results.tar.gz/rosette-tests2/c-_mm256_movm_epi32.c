#include "../c-test-helper.h"
int main() {
uint8_t _0[1] = { 0x0 };__mmask8 k;memcpy(&k, _0, 1);
uint8_t out[64] = {0};
__m256i ret = _mm256_movm_epi32(k);
memcpy(out, &ret, 32);
hex_out(out, 32);
return 0;
}