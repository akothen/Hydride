#include "../c-test-helper.h"
int main() {
uint8_t _0[1] = { 0x0 };__mmask8 k;memcpy(&k, _0, 1);
uint8_t _1[8] = { 0x0,0x1,0x2,0x3,0x4,0x5,0x6,0x7 };int64_t a;memcpy(&a, _1, 8);
uint8_t out[64] = {0};
__m128i ret = _mm_maskz_set1_epi64(k,a);
memcpy(out, &ret, 16);
hex_out(out, 16);
return 0;
}