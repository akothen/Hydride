#include "../c-test-helper.h"
int main() {
uint8_t _0[8] = { 0x0,0x1,0x2,0x3,0x4,0x5,0x6,0x7 };__mmask64 a;memcpy(&a, _0, 8);
uint8_t out[64] = {0};
uint64_t ret = _cvtmask64_u64(a);
memcpy(out, &ret, 8);
hex_out(out, 8);
return 0;
}