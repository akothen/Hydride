#include "../c-test-helper.h"
int main() {
uint8_t _0[4] = { 0x0,0x1,0x2,0x3 };unsigned int a;memcpy(&a, _0, 4);
uint8_t out[64] = {0};
int ret = _mm_tzcnt_32(a);
memcpy(out, &ret, 4);
hex_out(out, 4);
return 0;
}