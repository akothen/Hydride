#include "../c-test-helper.h"
int main() {
uint8_t out[64] = {0};
__m128i ret = _mm_setzero_si128();
memcpy(out, &ret, 16);
hex_out(out, 16);
return 0;
}