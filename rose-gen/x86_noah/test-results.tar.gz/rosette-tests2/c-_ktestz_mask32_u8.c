#include "../c-test-helper.h"
int main() {
uint8_t _0[4] = { 0x0,0x1,0x2,0x3 };__mmask32 a;memcpy(&a, _0, 4);
uint8_t _1[4] = { 0x0,0x1,0x2,0x3 };__mmask32 b;memcpy(&b, _1, 4);
uint8_t out[64] = {0};
unsigned char ret = _ktestz_mask32_u8(a,b);
memcpy(out, &ret, 1);
hex_out(out, 1);
return 0;
}