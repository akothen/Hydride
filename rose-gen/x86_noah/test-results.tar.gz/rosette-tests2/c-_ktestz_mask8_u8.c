#include "../c-test-helper.h"
int main() {
uint8_t _0[1] = { 0x0 };__mmask8 a;memcpy(&a, _0, 1);
uint8_t _1[1] = { 0x0 };__mmask8 b;memcpy(&b, _1, 1);
uint8_t out[64] = {0};
unsigned char ret = _ktestz_mask8_u8(a,b);
memcpy(out, &ret, 1);
hex_out(out, 1);
return 0;
}