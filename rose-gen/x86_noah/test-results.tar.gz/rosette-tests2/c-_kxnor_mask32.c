#include "../c-test-helper.h"
int main() {
uint8_t _0[4] = { 0x0,0x1,0x2,0x3 };__mmask32 a;memcpy(&a, _0, 4);
uint8_t _1[4] = { 0x0,0x1,0x2,0x3 };__mmask32 b;memcpy(&b, _1, 4);
uint8_t out[64] = {0};
__mmask32 ret = _kxnor_mask32(a,b);
memcpy(out, &ret, 4);
hex_out(out, 4);
return 0;
}