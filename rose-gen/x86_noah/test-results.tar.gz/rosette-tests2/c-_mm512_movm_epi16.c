#include "../c-test-helper.h"
int main() {
uint8_t _0[4] = { 0x0,0x1,0x2,0x3 };__mmask32 k;memcpy(&k, _0, 4);
uint8_t out[64] = {0};
__m512i ret = _mm512_movm_epi16(k);
memcpy(out, &ret, 64);
hex_out(out, 64);
return 0;
}